# The first test shell has no reflection-dependent application classes.
