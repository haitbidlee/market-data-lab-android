# Market Data Lab Android test shell

This is the first Android test shell for the Market Data Lab mobile dashboard.

## Current scope

- Opens the Free dashboard as the app home screen.
- Preserves the website's responsive mobile and tablet layouts.
- Supports JavaScript, cookies, local storage, back navigation, loading progress, and retry on connection failure.
- Opens non-dashboard links in the device browser.
- Requests only Internet and network-state permissions.

## Build in Android Studio

1. Open this folder in the latest stable Android Studio.
2. Allow Gradle sync to install Android SDK 35 and project dependencies.
3. Select an Android device or emulator and run the `app` configuration.
4. For a test APK, choose **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. Do not create the Play signing key until the package name and final brand name are confirmed.

## Build the test APK with GitHub Actions

Pushing this project to the `main` branch of a GitHub repository starts the included **Build test APK** workflow.

1. Open **Actions > Build test APK** in the repository.
2. Select **Run workflow**. The first push to `main` also starts it automatically.
3. Download the `Market-Data-Lab-test-APK` artifact from the completed run.
4. Unzip it and install `app-debug.apk` on an Android device.

## Provisional identifiers

- Display name: `Market Data Lab`
- Package name: `com.marketdatalab.app`
- Start URL: `https://market-data-lab-free.haitbid-lee.chatgpt.site`

The display name can be changed later. The package name should be finalized before the first Play Console upload.
